#!/bin/sh
# launcher.sh

sudo python /home/pi/pythonscripts/fan2.py &
