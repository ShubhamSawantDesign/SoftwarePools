
import RPi.GPIO as GPIO
import time
from gpiozero import CPUTemperature
cpu = CPUTemperature()

fanpin =  14

hightemp = 45     #high temp to trigger relay on
temp = cpu.temperature
lowtemp =  38

def Setup():
            GPIO.setwarnings(False)
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(fanpin,GPIO.OUT)

def FanOn():
            GPIO.output(fanpin,True)

def FanOff():
             GPIO.cleanup()

def CheckTemp():
          temp = cpu.temperature
          return temp
def PinStatus(pin):
            Setup()
            state = GPIO.input(pin)
            return state
try:
    while True:
              # print "Checking the Temperature Please Wait......!"
               if CheckTemp() >= hightemp:
                         Setup()
                         FanOn()
                        # msg =  "FAN needs to be on CPU temperature is",CheckTemp()
                        # print msg
                        # CreateLog(msg)
                         time.sleep(10)

               elif CheckTemp() <= lowtemp:
                   FanOff()
                  # msg1 = "FAN closing Down CPU temperature is",CheckTemp()
                  # CreateLog(msg1)
                  # print msg1
                   time.sleep(10)
               else:
                  # msg2 = "System Health is Good temperature is",CheckTemp()
                  # CreateLog(msg2)
                  # print msg2
                   time.sleep(10)

except KeyboardInterrupt:
         # print "End of Program"
          GPIO.cleanup()
